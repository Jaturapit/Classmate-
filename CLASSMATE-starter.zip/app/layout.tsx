import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "CLASSMATE — จัดการงานห้องเรียน",
  description: "พื้นที่จัดการงานและกำหนดส่งร่วมกัน",
  manifest: "/manifest.json",
};
export const viewport: Viewport = { themeColor: "#155eef", width: "device-width", initialScale: 1 };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="th"><body>{children}</body></html>;
}