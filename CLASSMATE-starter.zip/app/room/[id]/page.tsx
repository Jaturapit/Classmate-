"use client";
import { useEffect,useState } from "react";
import { useParams,useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";
type Assignment={id:string;title:string;description:string|null;due_date:string|null;created_by:string};
export default function RoomPage(){
 const {id}=useParams<{id:string}>();const router=useRouter();const [room,setRoom]=useState<any>(null);const [tasks,setTasks]=useState<Assignment[]>([]);
 const [user,setUser]=useState<any>(null);const [title,setTitle]=useState("");const [desc,setDesc]=useState("");const [due,setDue]=useState("");const [notice,setNotice]=useState("");
 async function load(){
  const {data:{user}}=await supabase.auth.getUser();if(!user){router.replace("/login");return}setUser(user);
  const {data:r}=await supabase.from("rooms").select("*").eq("id",id).single();setRoom(r);
  const {data:a}=await supabase.from("assignments").select("*").eq("room_id",id).order("created_at",{ascending:false});setTasks(a||[]);
 }
 useEffect(()=>{if(id)load()},[id]);
 async function addTask(){
  if(!title.trim())return;const {error}=await supabase.from("assignments").insert({room_id:id,title:title.trim(),description:desc||null,due_date:due||null,created_by:user.id});
  if(error)setNotice(error.message);else{setTitle("");setDesc("");setDue("");setNotice("เพิ่มงานแล้ว");load()}
 }
 async function saveTask(taskId:string){
  const {error}=await supabase.from("personal_tasks").upsert({user_id:user.id,assignment_id:taskId},{onConflict:"user_id,assignment_id"});
  setNotice(error?error.message:"บันทึกลงงานส่วนตัวแล้ว");
 }
 async function removeTask(t:Assignment){
  if(!confirm("ต้องการลบงานนี้หรือไม่?"))return;const {error}=await supabase.from("assignments").delete().eq("id",t.id);
  setNotice(error?error.message:"ลบงานแล้ว");load();
 }
 return <main className="page"><div className="wrap">
 <div className="topbar"><button className="btn ghost" onClick={()=>router.push("/dashboard")}>← กลับหน้าหลัก</button><div className="brand">CLASS<span>MATE</span></div></div>
 <section className="card"><div className="between"><div><h1>{room?.name||"ห้องเรียน"}</h1><div className="muted">รหัสเข้าห้อง: <b className="code">{room?.join_code||"----"}</b></div></div><span className="pill">พื้นที่ส่วนกลาง</span></div></section>
 {notice&&<p className="success">{notice}</p>}
 <div className="two" style={{marginTop:18}}>
 <section className="card"><h2>＋ เพิ่มงานใหม่</h2><label>ชื่องาน</label><input className="input" value={title} onChange={e=>setTitle(e.target.value)} placeholder="ระบุชื่องาน"/>
 <label>รายละเอียด</label><textarea className="input" rows={3} value={desc} onChange={e=>setDesc(e.target.value)} placeholder="รายละเอียดหรือคำชี้แจง"/>
 <label>กำหนดส่ง</label><input className="input" type="date" value={due} onChange={e=>setDue(e.target.value)}/>
 <button className="btn" disabled={!title.trim()} onClick={addTask}>เผยแพร่งานในห้อง</button></section>
 <section className="card"><h2>งานทั้งหมดในห้อง</h2>{tasks.length===0?<div className="empty">ยังไม่มีงานในห้องนี้</div>:tasks.map(t=><div className="task" key={t.id}>
 <div className="between"><b>{t.title}</b>{t.due_date&&<span className="pill">{t.due_date}</span>}</div>
 {t.description&&<p className="muted">{t.description}</p>}
 <div className="row"><button className="btn secondary" onClick={()=>saveTask(t.id)}>บันทึกงานของฉัน</button>{user?.id===t.created_by&&<button className="btn ghost" onClick={()=>removeTask(t)}>ลบงาน</button>}</div>
 </div>)}</section>
 </div>
 </div></main>
}