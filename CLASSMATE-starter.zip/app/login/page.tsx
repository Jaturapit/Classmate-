"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { useRouter } from "next/navigation";
export default function Login(){
 const [loading,setLoading]=useState(false); const [error,setError]=useState(""); const router=useRouter();
 useEffect(()=>{supabase.auth.getSession().then(({data})=>{if(data.session)router.replace("/dashboard")})},[router]);
 async function signIn(){setLoading(true);setError("");const {error}=await supabase.auth.signInWithOAuth({provider:"google",options:{redirectTo:location.origin+"/auth/callback"}});if(error){setError(error.message);setLoading(false)}}
 return <main className="page"><div className="hero card">
 <div className="brand">CLASS<span>MATE</span></div><p className="muted">พื้นที่จัดการงานห้องเรียน ทำงานร่วมกันได้ในที่เดียว</p>
 <div style={{height:20}}/><h1>ยินดีต้อนรับ 👋</h1><p className="muted">เข้าสู่ระบบเพื่อดูห้องเรียนและกำหนดส่งงานของคุณ</p>
 <button className="btn" style={{width:"100%",marginTop:16}} onClick={signIn} disabled={loading}>{loading?"กำลังเชื่อมต่อ...":"เข้าสู่ระบบด้วย Google"}</button>
 {error&&<p className="error">{error}</p>}<p className="muted" style={{marginTop:22,fontSize:12}}>เมื่อเข้าสู่ระบบ แสดงว่าคุณยอมรับการใช้งาน CLASSMATE</p>
 </div></main>
}