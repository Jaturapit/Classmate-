"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";
export default function AuthCallback(){
 const router=useRouter();const [message,setMessage]=useState("กำลังเข้าสู่ระบบ...");
 useEffect(()=>{
  async function finish(){
   const code=new URLSearchParams(window.location.search).get("code");
   if(code){const {error}=await supabase.auth.exchangeCodeForSession(code);if(error){setMessage("เข้าสู่ระบบไม่สำเร็จ: "+error.message);return}}
   const {data:{session}}=await supabase.auth.getSession();
   if(session)router.replace("/dashboard");else setMessage("ไม่พบเซสชัน กรุณากลับไปเข้าสู่ระบบอีกครั้ง");
  }
  finish();
 },[router]);
 return <main className="page"><div className="hero card"><div className="brand">CLASS<span>MATE</span></div><p>{message}</p><a className="link" href="/login">กลับไปหน้าเข้าสู่ระบบ</a></div></main>
}