"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";
type Room={id:string;name:string;join_code:string;role:string};
type Task={id:string;title:string;due_date:string|null;rooms?:{name:string}|null};
export default function Dashboard(){
 const router=useRouter(); const [user,setUser]=useState<any>(null); const [rooms,setRooms]=useState<Room[]>([]);
 const [tasks,setTasks]=useState<Task[]>([]); const [roomName,setRoomName]=useState(""); const [joinCode,setJoinCode]=useState("");
 const [msg,setMsg]=useState(""); const [busy,setBusy]=useState(false);
 async function load(){
  const {data:{user}}=await supabase.auth.getUser(); if(!user){router.replace("/login");return} setUser(user);
  const {data:members}=await supabase.from("room_members").select("role, rooms(id,name,join_code)").eq("user_id",user.id);
  setRooms((members||[]).map((m:any)=>({...m.rooms,role:m.role})).filter(Boolean));
  const {data:saved}=await supabase.from("personal_tasks").select("id, assignment_id, assignments(id,title,due_date,rooms(name))").eq("user_id",user.id).order("created_at",{ascending:false});
  setTasks((saved||[]).map((x:any)=>({id:x.id,title:x.assignments?.title||"งานที่ถูกลบ",due_date:x.assignments?.due_date,rooms:x.assignments?.rooms})));
 }
 useEffect(()=>{load()},[]);
 async function createRoom(){
  if(!roomName.trim())return;setBusy(true);setMsg("");
  const code=String(Math.floor(1000+Math.random()*9000));
  const {data,error}=await supabase.from("rooms").insert({name:roomName.trim(),join_code:code,owner_id:user.id}).select().single();
  if(error){setMsg(error.message)}else{const {error:e}=await supabase.from("room_members").insert({room_id:data.id,user_id:user.id,role:"owner"});if(e)setMsg(e.message);else{setRoomName("");setMsg("สร้างห้องสำเร็จ รหัสห้อง: "+code);load()}}
  setBusy(false);
 }
 async function joinRoom(){
  setBusy(true);setMsg("");const {data,error}=await supabase.rpc("join_room_by_code",{p_code:joinCode.trim()});
  if(error)setMsg(error.message);else{setMsg("เข้าร่วมห้องสำเร็จ");setJoinCode("");load()}setBusy(false);
 }
 async function logout(){await supabase.auth.signOut();router.replace("/login")}
 return <main className="page"><div className="wrap">
 <header className="topbar"><div><div className="brand">CLASS<span>MATE</span></div><div className="muted">จัดการงานห้องเรียนให้ง่ายขึ้น</div></div><button className="btn ghost" onClick={logout}>ออกจากระบบ</button></header>
 <div className="between" style={{marginBottom:18}}><div><h1>สวัสดี{user?.user_metadata?.full_name?" "+user.user_metadata.full_name:""} 👋</h1><div className="muted">พื้นที่ทำงานของคุณ</div></div><span className="pill">บัญชีของฉัน</span></div>
 {msg&&<p className="success">{msg}</p>}
 <section className="grid">
 <div className="card"><h2>＋ สร้างห้องเรียน</h2><label>ชื่อห้อง</label><input className="input" placeholder="เช่น ม.6/1 ห้องเรียนรวม" value={roomName} onChange={e=>setRoomName(e.target.value)}/><button className="btn" disabled={busy||!roomName.trim()} onClick={createRoom}>สร้างห้อง</button></div>
 <div className="card"><h2>⇢ เข้าร่วมห้อง</h2><label>รหัสห้อง 4 หลัก</label><input className="input" inputMode="numeric" maxLength={4} placeholder="กรอกรหัสห้อง" value={joinCode} onChange={e=>setJoinCode(e.target.value.replace(/\D/g,""))}/><button className="btn secondary" disabled={busy||joinCode.length!==4} onClick={joinRoom}>เข้าร่วมห้อง</button></div>
 <div className="card"><h2>งานของฉัน</h2><div style={{fontSize:34,fontWeight:700,color:"var(--blue)"}}>{tasks.length}</div><div className="muted">งานที่บันทึกไว้ส่วนตัว</div></div>
 </section>
 <div className="two" style={{marginTop:18}}>
 <section className="card"><div className="between"><h2>ห้องเรียนของฉัน</h2><span className="pill">{rooms.length} ห้อง</span></div>
 {rooms.length===0?<div className="empty">ยังไม่มีห้องเรียน เริ่มจากสร้างห้องหรือเข้าร่วมห้อง</div>:<div className="stack">{rooms.map(r=><div className="room" key={r.id}><div><b>{r.name}</b><div className="muted">บทบาท: {r.role==="owner"?"เจ้าของห้อง":r.role==="admin"?"ผู้ดูแล":"สมาชิก"}</div></div><button className="btn secondary" onClick={()=>router.push("/room/"+r.id)}>เปิดห้อง</button></div>)}</div>}
 </section>
 <section className="card"><h2>งานที่บันทึกไว้</h2>{tasks.length===0?<div className="empty">งานที่คุณกดบันทึกจากห้องเรียนจะแสดงที่นี่</div>:tasks.slice(0,8).map(t=><div className="task" key={t.id}><b>{t.title}</b><div className="muted">{t.rooms?.name||"ห้องเรียน"} · {t.due_date||"ไม่ระบุกำหนดส่ง"}</div></div>)}</section>
 </div>
 <p className="muted" style={{textAlign:"center",marginTop:24}}>CLASSMATE · Modern Blue</p>
 </div></main>
}