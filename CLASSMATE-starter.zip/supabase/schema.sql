-- CLASSMATE database setup
-- Run the entire file in Supabase > SQL Editor > New query.
create extension if not exists pgcrypto;

create table if not exists public.rooms (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 join_code text not null unique check (join_code ~ '^[0-9]{4}$'),
 owner_id uuid not null references auth.users(id) on delete cascade,
 created_at timestamptz not null default now()
);
create table if not exists public.room_members (
 room_id uuid references public.rooms(id) on delete cascade,
 user_id uuid references auth.users(id) on delete cascade,
 role text not null default 'member' check (role in ('owner','admin','member')),
 joined_at timestamptz not null default now(),
 primary key(room_id,user_id)
);
create table if not exists public.assignments (
 id uuid primary key default gen_random_uuid(),
 room_id uuid not null references public.rooms(id) on delete cascade,
 title text not null,
 description text,
 due_date date,
 created_by uuid not null references auth.users(id) on delete cascade,
 created_at timestamptz not null default now()
);
create table if not exists public.personal_tasks (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 assignment_id uuid not null references public.assignments(id) on delete cascade,
 created_at timestamptz not null default now(),
 unique(user_id,assignment_id)
);
create table if not exists public.comments (
 id uuid primary key default gen_random_uuid(),
 assignment_id uuid not null references public.assignments(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 parent_id uuid references public.comments(id) on delete cascade,
 body text not null,
 created_at timestamptz not null default now()
);

alter table public.rooms enable row level security;
alter table public.room_members enable row level security;
alter table public.assignments enable row level security;
alter table public.personal_tasks enable row level security;
alter table public.comments enable row level security;

-- Helper: check membership without recursive RLS
create or replace function public.is_room_member(p_room uuid)
returns boolean language sql security definer set search_path=public
stable as $$
 select exists(select 1 from public.room_members where room_id=p_room and user_id=auth.uid());
$$;
grant execute on function public.is_room_member(uuid) to authenticated;

create policy "rooms visible to members" on public.rooms for select to authenticated
using (owner_id=auth.uid() or public.is_room_member(id));
create policy "create own rooms" on public.rooms for insert to authenticated
with check (owner_id=auth.uid());
create policy "owner updates room" on public.rooms for update to authenticated
using (owner_id=auth.uid()) with check (owner_id=auth.uid());
create policy "owner deletes room" on public.rooms for delete to authenticated
using (owner_id=auth.uid());

create policy "members can view memberships" on public.room_members for select to authenticated
using (user_id=auth.uid() or public.is_room_member(room_id));
create policy "owner adds members" on public.room_members for insert to authenticated
with check (user_id=auth.uid() and (role='owner' or exists(select 1 from public.rooms r where r.id=room_id and r.owner_id=auth.uid())));
create policy "owner manages memberships" on public.room_members for delete to authenticated
using (exists(select 1 from public.rooms r where r.id=room_id and r.owner_id=auth.uid()) or user_id=auth.uid());

create policy "members view assignments" on public.assignments for select to authenticated
using (public.is_room_member(room_id));
create policy "members add assignments" on public.assignments for insert to authenticated
with check (created_by=auth.uid() and public.is_room_member(room_id));
create policy "creator or owner deletes assignments" on public.assignments for delete to authenticated
using (created_by=auth.uid() or exists(select 1 from public.rooms r where r.id=room_id and r.owner_id=auth.uid()));
create policy "creator updates assignments" on public.assignments for update to authenticated
using (created_by=auth.uid() or exists(select 1 from public.rooms r where r.id=room_id and r.owner_id=auth.uid()))
with check (created_by=auth.uid() or exists(select 1 from public.rooms r where r.id=room_id and r.owner_id=auth.uid()));

create policy "users view own personal tasks" on public.personal_tasks for select to authenticated using(user_id=auth.uid());
create policy "users save own tasks" on public.personal_tasks for insert to authenticated
with check(user_id=auth.uid() and exists(select 1 from public.assignments a where a.id=assignment_id and public.is_room_member(a.room_id)));
create policy "users remove own tasks" on public.personal_tasks for delete to authenticated using(user_id=auth.uid());

create policy "room members view comments" on public.comments for select to authenticated
using(exists(select 1 from public.assignments a where a.id=assignment_id and public.is_room_member(a.room_id)));
create policy "room members add comments" on public.comments for insert to authenticated
with check(user_id=auth.uid() and exists(select 1 from public.assignments a where a.id=assignment_id and public.is_room_member(a.room_id)));
create policy "comment author deletes" on public.comments for delete to authenticated using(user_id=auth.uid());

-- Join using a 4-digit code. Server-side check; user is added only once.
create or replace function public.join_room_by_code(p_code text)
returns uuid language plpgsql security definer set search_path=public
as $$
declare found_room uuid;
begin
 if auth.uid() is null then raise exception 'กรุณาเข้าสู่ระบบก่อน'; end if;
 select id into found_room from public.rooms where join_code=p_code limit 1;
 if found_room is null then raise exception 'ไม่พบรหัสห้องนี้'; end if;
 insert into public.room_members(room_id,user_id,role) values(found_room,auth.uid(),'member')
 on conflict(room_id,user_id) do nothing;
 return found_room;
end;
$$;
grant execute on function public.join_room_by_code(text) to authenticated;

-- Realtime for shared room work
alter publication supabase_realtime add table public.assignments;
alter publication supabase_realtime add table public.comments;
