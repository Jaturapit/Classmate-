# CLASSMATE — คู่มือเริ่มต้นบน iPad

โปรเจกต์เริ่มต้นสำหรับเว็บจัดการงานห้องเรียน โทน Modern Blue

## ส่วนที่มีในเวอร์ชันเริ่มต้น
- เข้าสู่ระบบด้วย Google และคงสถานะการเข้าสู่ระบบ
- สร้างห้องเรียนและเข้าร่วมห้องด้วยรหัส 4 หลัก
- สมาชิกเพิ่มงานร่วมกัน
- ผู้สร้างงานหรือเจ้าของห้องลบงานได้
- บันทึกงานเข้ารายการส่วนตัว
- ฐานข้อมูลเปิดใช้ Row Level Security (RLS)

> เวอร์ชันนี้เป็น MVP สำหรับเริ่มทดสอบ ยังไม่ใช่ระบบเต็มตามรายการทั้งหมด: ปฏิทินแบบเดือน, คอมเมนต์ในหน้าเว็บ, ไฟล์แนบ, แจ้งเตือน, ระบบแต่งตั้งแอดมิน และ Push Notification ยังต้องพัฒนาต่อ

## ขั้นที่ 1: สร้างโปรเจกต์ Supabase
1. เปิด https://supabase.com แล้วสมัคร/เข้าสู่ระบบ
2. กด New project ตั้งชื่อ `classmate` และจดรหัสผ่านฐานข้อมูลไว้ในที่ปลอดภัย
3. เข้าเมนู SQL Editor > New query
4. เปิดไฟล์ `supabase/schema.sql` ใน GitHub แล้วคัดลอกทั้งหมดไปวาง จากนั้นกด Run
5. ไปที่ Project Settings > API แล้วคัดลอก Project URL และ anon/public key

## ขั้นที่ 2: เปิด Google Login
1. ใน Supabase ไปที่ Authentication > Providers > Google แล้วเปิดใช้งาน
2. ตั้งค่า Google OAuth ใน Google Cloud Console โดยทำตามคู่มือ Supabase:
   https://supabase.com/docs/guides/auth/social-login/auth-google
3. ใส่ Client ID และ Client Secret ในช่องของ Supabase
4. ตั้ง Site URL และ Redirect URL เป็นโดเมน Vercel ของคุณ และเพิ่ม `https://YOUR-PROJECT.vercel.app/auth/callback`
   ระหว่างพัฒนาสามารถเพิ่ม URL preview ที่จำเป็นได้ด้วย

## ขั้นที่ 3: นำโค้ดเข้า GitHub
1. เปิด https://github.com ใน Safari แล้วกด New repository
2. ตั้งชื่อ `classmate` เลือก Private หรือ Public ตามต้องการ แล้ว Create repository
3. อัปโหลดไฟล์จาก ZIP นี้ทั้งหมดเข้า repository (แตก ZIP ก่อน)
4. ตรวจให้เห็น `package.json`, โฟลเดอร์ `app`, `lib` และ `supabase`

## ขั้นที่ 4: เผยแพร่ด้วย Vercel
1. เปิด https://vercel.com แล้ว Continue with GitHub
2. กด Add New > Project แล้วเลือก repository `classmate`
3. Framework จะตรวจพบ Next.js อัตโนมัติ
4. ใน Environment Variables เพิ่ม:
   - `NEXT_PUBLIC_SUPABASE_URL` = Project URL จาก Supabase
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY` = anon/public key จาก Supabase
5. กด Deploy และรอจนเสร็จ จากนั้นเปิดโดเมนที่ได้

## ขั้นที่ 5: ตั้งค่า URL สำหรับ Google Login
หลัง Vercel สร้างโดเมนให้แล้ว กลับไปที่ Supabase > Authentication > URL Configuration:
- Site URL: `https://โดเมนของคุณ.vercel.app`
- Redirect URLs: `https://โดเมนของคุณ.vercel.app/auth/callback`

กลับไปที่ Google Cloud Console ตรวจ Authorized redirect URI ให้ตรงกับ Callback URL ที่ Supabase แสดงในหน้า Google provider (ไม่ใช่ URL ของ Vercel)

## เปิดบน iPad เหมือนแอป
เปิดเว็บผ่าน Safari > ปุ่มแชร์ > Add to Home Screen

## ข้อควรระวัง
- ห้ามส่ง Google Client Secret หรือ Supabase service_role key ให้ใคร และห้ามใส่ลงในไฟล์หน้าเว็บ
- ใช้เฉพาะ anon/public key ในตัวแปร `NEXT_PUBLIC_SUPABASE_ANON_KEY` เพราะมี RLS คุมสิทธิ์ในฐานข้อมูล
- รหัสห้อง 4 หลักเดาง่าย ควรแชร์เฉพาะสมาชิกที่ต้องการ และเปลี่ยนรหัสเมื่อมีคนนอกเข้าห้อง
- ก่อนใช้กับทั้งห้อง ให้ทดสอบด้วยบัญชี 2 บัญชีและข้อมูลตัวอย่างก่อน
- แพ็กเกจฟรีของผู้ให้บริการมีโควตาและเงื่อนไขเปลี่ยนแปลงได้ ควรตรวจสอบหน้า Pricing ล่าสุด
